package com.example.afc

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Settings.canDrawOverlays(c)) c.startForegroundService(Intent(c, IslandService::class.java))
    }
}
