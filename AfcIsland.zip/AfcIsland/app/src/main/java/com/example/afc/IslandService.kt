package com.example.afc

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.exp

class IslandService : Service() {
    companion object {
        const val ACTION_SHOW = "show"
        const val ACTION_RELOAD = "reload"
        const val ACTION_FAST = "fast"
        const val ACTION_SLOW = "slow"
        const val NODE = "/sys/class/sec/switch/afc_disable"
        const val CUR = "/sys/class/power_supply/battery/batt_current_ua_now"
        val GREEN = 0xFF30D158.toInt()
        val BLUE = 0xFF0A84FF.toInt()
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var bm: BatteryManager
    private lateinit var notif: Notification
    private val prefs by lazy { getSharedPreferences("afc", MODE_PRIVATE) }
    private val dp get() = resources.displayMetrics.density

    private var plugged = false
    private var lastSched = -1
    private var curMode = -1      // real state of the node (0 fast, 1 slow)
    private var wantMode = -1     // what we last asked for
    private var lastWrite = 0L
    private var retries = 0
    private var fullUah = 0L

    // live numbers
    private var lastT = 0L
    private var lastSample = 0L
    private var openedAt = 0L
    private var sCap = 0
    private var sFull = 0.0
    private var charging = false
    private var targetMa = 0.0
    private var shownMa = 0.0
    private var hasTarget = false
    private var lastReading = -1.0
    private var deadline = 0L

    // persistent root reader
    @Volatile private var rootMa = -1.0
    @Volatile private var rootNode = -1
    @Volatile private var readerGen = 0
    private var readerProc: java.lang.Process? = null

    private var holder: FrameLayout? = null
    private lateinit var card: SwipeCard
    private lateinit var battery: BatteryView
    private lateinit var pctText: TextView
    private lateinit var statusText: TextView
    private lateinit var etaText: TextView
    private lateinit var fastBtn: TextView
    private lateinit var slowBtn: TextView

    override fun onBind(i: Intent?): IBinder? = null

    private val hideRun = Runnable { hideIsland(true) }

    private val tick = object : Runnable {
        override fun run() {
            if (!plugged) return
            checkSchedule()
            ui.postDelayed(this, 30000)
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (holder == null) return
            step()
            pctText.text = "$sCap%"
            battery.set(sCap.toDouble(), if (curMode == 1) BLUE else GREEN, curMode != 1)
            updateStatus()
            etaText.text = etaText()
            ui.postDelayed(this, 50)
        }
    }

    private val unplugCheck = Runnable {
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if ((st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) == 0) {
            plugged = false; ui.removeCallbacks(tick); hideIsland(false); endLive()
        }
    }

    private val powerRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val recent = SystemClock.elapsedRealtime() - lastWrite < 8000
            if (i.action == Intent.ACTION_POWER_CONNECTED) {
                plugged = true
                ui.removeCallbacks(unplugCheck)
                beginLive()
                ui.postDelayed({
                    if (plugged) {
                        if (!recent) { lastSched = -1; ui.removeCallbacks(tick); ui.post(tick) }
                        showIsland()
                    }
                }, 2500)
            } else {
                // changing the charge mode makes the charger blink; don't treat that as an unplug
                ui.removeCallbacks(unplugCheck)
                if (recent) ui.postDelayed(unplugCheck, 4000) else ui.post(unplugCheck)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("live", "Charging status", NotificationManager.IMPORTANCE_LOW))
        notif = buildNotif("AFC Island", "Waiting for charger")

        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        plugged = (st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        registerReceiver(powerRx, IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        })
        if (plugged) { ui.post(tick); beginLive() }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(1, notif)
        when (i?.action) {
            ACTION_SHOW -> showIsland()
            ACTION_FAST -> setManual(0)
            ACTION_SLOW -> setManual(1)
            ACTION_RELOAD -> if (plugged) { lastSched = -1; ui.removeCallbacks(tick); ui.post(tick) }
        }
        return START_STICKY
    }

    // ---------- root helpers ----------
    private fun su(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o.trim()
    } catch (e: Exception) { "" }

    private fun bg(b: () -> Unit) { Thread(b).start() }

    // one long-lived root shell that reads the live current and the real mode node ~4x per second
    private fun startReader() {
        val gen = ++readerGen
        rootMa = -1.0; rootNode = -1
        Thread {
            var p: java.lang.Process? = null
            try {
                val pr = Runtime.getRuntime().exec("su")
                p = pr; readerProc = pr
                val w = pr.outputStream.bufferedWriter()
                val r = pr.inputStream.bufferedReader()
                val rx = Regex("I(-?\\d*) M(\\d*)")
                while (gen == readerGen) {
                    w.write("echo \"I\$(cat $CUR 2>/dev/null) M\$(cat $NODE 2>/dev/null)\"\n"); w.flush()
                    val line = r.readLine() ?: break
                    val m = rx.find(line)
                    if (m != null) {
                        m.groupValues[1].toLongOrNull()?.let { rootMa = abs(it) / 1000.0 }
                        m.groupValues[2].toIntOrNull()?.let { rootNode = it }
                    }
                    Thread.sleep(250)
                }
            } catch (_: Exception) {}
            try { p?.destroy() } catch (_: Exception) {}
        }.start()
    }

    private fun stopReader() { readerGen++; try { readerProc?.destroy() } catch (_: Exception) {} }

    private fun rounded(color: Int, r: Float): Drawable =
        GradientDrawable().apply { setColor(color); cornerRadius = r * dp }

    // ---------- charging mode + schedule ----------
    private fun inSlowWindow(): Boolean {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val s = prefs.getInt("slow_start", 21 * 60)
        val e = prefs.getInt("slow_end", 5 * 60)
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    private fun lastBoundaryMs(): Long {
        val now = System.currentTimeMillis()
        var best = 0L
        for (m in intArrayOf(prefs.getInt("slow_start", 21 * 60), prefs.getInt("slow_end", 5 * 60))) {
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis > now) c.add(Calendar.DAY_OF_YEAR, -1)
            best = maxOf(best, c.timeInMillis)
        }
        return best
    }

    private fun desired(): Int {
        val man = prefs.getInt("manual", -1)
        if (!prefs.getBoolean("sched_on", true)) return man
        if (man >= 0 && prefs.getLong("manual_ts", 0L) > lastBoundaryMs()) return man
        return if (inSlowWindow()) 1 else 0
    }

    private fun checkSchedule() {
        val d = desired()
        if (d < 0) return
        if (d != lastSched) {
            lastSched = d; retries = 0; writeMode(d)
        } else bg {
            // the system may have flipped it back; re-assert
            val v = su("cat $NODE").toIntOrNull()
            if (v != null && v != d) su("echo $d > $NODE")
        }
    }

    private fun writeMode(m: Int) {
        wantMode = m
        lastWrite = SystemClock.elapsedRealtime()
        bg { su("echo $m > $NODE") }
    }

    private fun setManual(m: Int) {
        prefs.edit().putInt("manual", m).putLong("manual_ts", System.currentTimeMillis()).apply()
        lastSched = m; retries = 0
        writeMode(m)
        updateModeUi()
    }

    // ---------- live numbers ----------
    private fun bmMa(): Double {
        val v = abs(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)).toDouble()
        return if (v <= 0) -1.0 else if (v < 10000) v else v / 1000.0
    }

    // mA: starts at 0 and creeps up slowly until a real reading arrives, then accelerates to it.
    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val first = lastT == 0L
        val dt = if (first) 0.0 else (now - lastT) / 1000.0
        lastT = now
        if (first || now - lastSample >= 250) {
            lastSample = now
            sCap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val c = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            sFull = if (fullUah > 0) fullUah.toDouble() else if (sCap > 0 && c > 0) c * 100.0 / sCap else 0.0
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val stt = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val plg = bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
            charging = stt == BatteryManager.BATTERY_STATUS_CHARGING ||
                (plg != 0 && stt != BatteryManager.BATTERY_STATUS_NOT_CHARGING &&
                    stt != BatteryManager.BATTERY_STATUS_DISCHARGING && stt != BatteryManager.BATTERY_STATUS_FULL)
            val r = if (rootMa >= 0) rootMa else if (now - openedAt > 1500) bmMa() else -1.0
            if (r > 0 && abs(r - lastReading) >= 1.0) { lastReading = r; targetMa = r; hasTarget = true }
            val n = rootNode
            if (n in 0..1) {
                if (n != curMode) { curMode = n; updateModeUi() }
                if (wantMode >= 0 && n != wantMode && now - lastWrite > 1500 && retries < 6) {
                    retries++; writeMode(wantMode); updateModeUi()
                }
            }
        }
        if (hasTarget) shownMa += (targetMa - shownMa) * (1 - exp(-dt / 0.5))
        else shownMa = minOf(300.0, shownMa + 40.0 * dt)
    }

    // time to full from the live current; above 80% charging tapers, so it is weighted slower
    private fun etaText(): String {
        if (sCap >= 100) return "Fully charged"
        if (!charging) return "Not charging"
        if (shownMa < 80 || sFull <= 0) return "Estimating time…"
        val cur = shownMa * 1000.0
        val have = minOf(100.0, sCap + 0.5)
        val toFull = (100.0 - have) / 100.0 * sFull
        val above = (100.0 - maxOf(have, 80.0)) / 100.0 * sFull
        val hours = (toFull - above) / cur + above / (cur * 0.45)
        val mins = (hours * 60).toInt().coerceAtLeast(1)
        return if (mins >= 60) "Full in ${mins / 60}h ${mins % 60}m" else "Full in $mins min"
    }

    // ---------- background notification (like AccuBattery) ----------
    private var readerOn = false

    private fun ensureReader() { if (!readerOn) { readerOn = true; startReader() } }
    private fun releaseReader() { if (!plugged && holder == null && readerOn) { readerOn = false; stopReader() } }

    private fun resetLive() {
        lastT = 0L; shownMa = 0.0; targetMa = 0.0; hasTarget = false; lastReading = -1.0
        openedAt = SystemClock.elapsedRealtime()
    }

    private fun loadFull() = bg {
        if (fullUah == 0L) fullUah = su("cat /sys/class/power_supply/battery/charge_full").toLongOrNull() ?: 0L
    }

    private fun beginLive() {
        ensureReader(); loadFull()
        if (holder == null) resetLive()
        ui.removeCallbacks(notifTick); ui.post(notifTick)
    }

    private fun endLive() {
        ui.removeCallbacks(notifTick)
        postNotif("AFC Island", "Waiting for charger")
        releaseReader()
    }

    private val notifTick = object : Runnable {
        override fun run() {
            if (!plugged) return
            if (holder == null) step()
            val mode = if (curMode == 0) "Rapid charging" else if (curMode == 1) "Slow charging" else "Charging"
            val ma = if (shownMa >= 1) "${shownMa.toInt()} mA · " else ""
            postNotif("$sCap% · $mode", ma + etaText())
            ui.postDelayed(this, 2000)
        }
    }

    private fun buildNotif(title: String, text: String): Notification {
        fun act(a: String, code: Int) = PendingIntent.getForegroundService(this, code,
            Intent(this, IslandService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "live")
            .setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
            .setContentIntent(open)
            .addAction(0, "⚡ Fast", act(ACTION_FAST, 1))
            .addAction(0, "🌙 Slow", act(ACTION_SLOW, 2))
            .build()
    }

    private fun postNotif(title: String, text: String) {
        notif = buildNotif(title, text)
        getSystemService(NotificationManager::class.java).notify(1, notif)
    }

    // ---------- island UI ----------
    private fun seg(t: String) = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; textSize = 13f; setTextColor(Color.WHITE)
        setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
    }

    private fun updateStatus() {
        if (holder == null) return
        val pending = wantMode >= 0 && curMode >= 0 && curMode != wantMode
        val label = if (pending) (if (retries >= 6) "MODE BLOCKED BY SYSTEM" else "SWITCHING…")
        else if (curMode == 0) "RAPID CHARGING" else if (curMode == 1) "SLOW CHARGING" else "CHARGING"
        statusText.text = if (shownMa >= 1) "$label · ${shownMa.toInt()} mA" else label
    }

    private fun updateModeUi() {
        if (holder == null) return
        val sel = if (wantMode >= 0) wantMode else curMode
        statusText.setTextColor(if (curMode == 1) BLUE else GREEN)
        fastBtn.background = if (sel == 0) rounded(0x6630D158, 12f) else null
        slowBtn.background = if (sel == 1) rounded(0x660A84FF, 12f) else null
        fastBtn.alpha = if (sel == 0) 1f else 0.6f
        slowBtn.alpha = if (sel == 1) 1f else 0.6f
        updateStatus()
    }

    private fun showIsland() {
        ui.removeCallbacks(hideRun)
        if (holder == null) build()
        deadline = SystemClock.elapsedRealtime() + 10000
        ui.postDelayed(hideRun, 10000)
    }

    // finger down = stay open; on release keep it at least 3 s more
    private fun holdIsland(held: Boolean) {
        if (holder == null) return
        ui.removeCallbacks(hideRun)
        if (!held) {
            val rem = maxOf(deadline - SystemClock.elapsedRealtime(), 3000L)
            deadline = SystemClock.elapsedRealtime() + rem
            ui.postDelayed(hideRun, rem)
        }
    }

    private fun build() {
        val d = dp
        battery = BatteryView(this)
        pctText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 26f; text = "--"
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        statusText = TextView(this).apply { textSize = 12f; letterSpacing = 0.08f }
        etaText = TextView(this).apply { textSize = 12f; setTextColor(0xFFB0B0B8.toInt()); text = "Estimating time…" }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(pctText); addView(statusText); addView(etaText)
        }
        val row1 = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(battery, LinearLayout.LayoutParams((56 * d).toInt(), (28 * d).toInt()))
            addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = (12 * d).toInt() })
        }
        fastBtn = seg("⚡ Fast"); slowBtn = seg("🌙 Slow")
        fastBtn.setOnClickListener { setManual(0) }
        slowBtn.setOnClickListener { setManual(1) }
        val segRow = LinearLayout(this).apply {
            background = rounded(0x22FFFFFF, 15f)
            val pd = (3 * d).toInt(); setPadding(pd, pd, pd, pd)
            addView(fastBtn, LinearLayout.LayoutParams(0, -2, 1f))
            addView(slowBtn, LinearLayout.LayoutParams(0, -2, 1f))
        }
        card = SwipeCard(this, { hideIsland(true) }, { held -> holdIsland(held) }).apply {
            orientation = LinearLayout.VERTICAL
            val pd = (16 * d).toInt(); setPadding(pd, (14 * d).toInt(), pd, (14 * d).toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF17171B.toInt(), 0xFF000000.toInt())).apply {
                cornerRadius = 32 * d; setStroke(maxOf(1, d.toInt()), 0x33FFFFFF)
            }
            addView(row1)
            addView(segRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * d).toInt() })
        }
        val h = FrameLayout(this).apply {
            val pd = (14 * d).toInt(); setPadding(pd, pd, pd, pd)
            addView(card, FrameLayout.LayoutParams(-1, -2))
        }
        val width = minOf((340 * d).toInt(), resources.displayMetrics.widthPixels)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }
        wm.addView(h, lp)
        holder = h

        card.alpha = 0f; card.scaleX = 0.5f; card.scaleY = 0.5f; card.translationY = -40 * d
        card.post {
            card.pivotX = card.width / 2f; card.pivotY = 0f
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(450).setInterpolator(OvershootInterpolator(1.2f)).start()
        }

        resetLive()
        updateModeUi()
        ensureReader()
        loadFull()
        ui.post(poll)
    }

    private fun hideIsland(animate: Boolean) {
        ui.removeCallbacks(hideRun); ui.removeCallbacks(poll)
        val h = holder ?: return
        holder = null
        releaseReader()
        val remove = { try { wm.removeView(h) } catch (_: Exception) {} }
        if (animate) {
            card.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).translationY(-24 * dp)
                .setDuration(250).withEndAction { remove() }.start()
        } else remove()
    }

    override fun onDestroy() {
        try { unregisterReceiver(powerRx) } catch (_: Exception) {}
        ui.removeCallbacksAndMessages(null)
        hideIsland(false)
        stopReader()
        super.onDestroy()
    }
}
