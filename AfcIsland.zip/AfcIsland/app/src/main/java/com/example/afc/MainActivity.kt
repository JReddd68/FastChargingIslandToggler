package com.example.afc

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("afc", MODE_PRIVATE) }
    private val dp get() = resources.displayMetrics.density
    private lateinit var permText: TextView
    private lateinit var permBtn: Button
    private lateinit var summary: TextView
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button

    private fun fmt(min: Int): String {
        val h = min / 60; val m = min % 60
        return String.format("%d:%02d %s", if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")
    }

    private fun btn(t: String) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(0xFF2A2A2E.toInt()); cornerRadius = 16 * dp }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * dp).toInt() }
    }

    private fun txt(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        permText = txt("", 14f, 0xFFFF9F0A.toInt())
        permBtn = btn("Grant overlay permission").apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val sw = Switch(this).apply {
            text = "Smart charging schedule"; setTextColor(Color.WHITE); textSize = 16f
            isChecked = prefs.getBoolean("sched_on", true)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("sched_on", on).apply(); refresh(); svc(IslandService.ACTION_RELOAD)
            }
        }
        summary = txt("", 14f, 0xFFB0B0B8.toInt())
        startBtn = btn("").apply { setOnClickListener { pick("slow_start", 21 * 60) } }
        endBtn = btn("").apply { setOnClickListener { pick("slow_end", 5 * 60) } }
        val preview = btn("Preview island (10 s)").apply { setOnClickListener { svc(IslandService.ACTION_SHOW) } }

        val pad = (20 * dp).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad)
            addView(txt("AFC Island", 28f))
            addView(permText); addView(permBtn)
            addView(View(context), LinearLayout.LayoutParams(-1, (20 * dp).toInt()))
            addView(sw)
            addView(summary)
            addView(startBtn); addView(endBtn)
            addView(View(context), LinearLayout.LayoutParams(-1, (20 * dp).toInt()))
            addView(preview)
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B0B0F.toInt()); addView(root) })
    }

    override fun onResume() { super.onResume(); refresh(); svc(IslandService.ACTION_RELOAD) }

    private fun svc(a: String) {
        if (Settings.canDrawOverlays(this))
            startForegroundService(Intent(this, IslandService::class.java).setAction(a))
    }

    private fun pick(key: String, def: Int) {
        val v = prefs.getInt(key, def)
        TimePickerDialog(this, { _, h, m ->
            prefs.edit().putInt(key, h * 60 + m).apply(); refresh(); svc(IslandService.ACTION_RELOAD)
        }, v / 60, v % 60, false).show()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        permText.visibility = if (ok) View.GONE else View.VISIBLE
        permBtn.visibility = if (ok) View.GONE else View.VISIBLE
        permText.text = "Overlay permission needed for the island."
        val s = prefs.getInt("slow_start", 21 * 60); val e = prefs.getInt("slow_end", 5 * 60)
        val on = prefs.getBoolean("sched_on", true)
        startBtn.text = "Slow charge starts: ${fmt(s)}"
        endBtn.text = "Slow charge ends: ${fmt(e)}"
        startBtn.isEnabled = on; endBtn.isEnabled = on
        startBtn.alpha = if (on) 1f else 0.4f; endBtn.alpha = startBtn.alpha
        summary.text = if (on) "Slow charge from ${fmt(s)} to ${fmt(e)}, fast charge the rest of the day."
        else "Schedule off. Pick Fast or Slow on the island; your last choice is re-applied when you plug in."
    }
}
