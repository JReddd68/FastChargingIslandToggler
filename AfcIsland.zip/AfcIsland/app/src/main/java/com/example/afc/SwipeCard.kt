package com.example.afc

import android.content.Context
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import kotlin.math.abs

class SwipeCard(c: Context, private val onDismiss: () -> Unit, private val onHold: (Boolean) -> Unit) : LinearLayout(c) {
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(c).scaledTouchSlop * 1.5f
    private var x0 = 0f
    private var y0 = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; dragging = false; onHold(true) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (!dragging) onHold(false)
            MotionEvent.ACTION_MOVE -> if (!dragging) {
                val dx = e.rawX - x0; val dy = e.rawY - y0
                if (abs(dx) > slop || dy < -slop) dragging = true
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - x0; val dy = minOf(0f, e.rawY - y0)
                translationX = dx; translationY = dy
                alpha = 1f - minOf(0.7f, abs(dx) / (width * 1.2f) + abs(dy) / (160 * d))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dx = e.rawX - x0; val dy = e.rawY - y0
                dragging = false
                if (e.actionMasked == MotionEvent.ACTION_UP && (abs(dx) > width * 0.3f || dy < -50 * d)) onDismiss()
                else {
                    animate().translationX(0f).translationY(0f).alpha(1f)
                        .setDuration(250).setInterpolator(OvershootInterpolator(1.5f)).start()
                    onHold(false)
                }
            }
        }
        return true
    }
}
