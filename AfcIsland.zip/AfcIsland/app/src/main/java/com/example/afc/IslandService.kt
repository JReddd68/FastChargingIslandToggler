package com.example.afc

import android.animation.ValueAnimator
import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*

class IslandService : Service() {
    private val node = "/sys/class/sec/switch/afc_disable"
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var pill: LinearLayout? = null
    private lateinit var label: TextView
    private lateinit var fastBtn: TextView
    private lateinit var slowBtn: TextView
    private var expanded = false
    private val dp get() = resources.displayMetrics.density
    private val prefs by lazy { getSharedPreferences("afc", MODE_PRIVATE) }
    private val collapse = Runnable { if (expanded) toggle() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val ch = NotificationChannel("afc", "AFC Island", NotificationManager.IMPORTANCE_MIN)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "afc")
            .setContentTitle("AFC Island running")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging).build())

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action == Intent.ACTION_POWER_CONNECTED) {
                    // kernel may reset the node on plug-in, so re-apply after a short delay
                    ui.postDelayed({ reapply(); showPill() }, 2500)
                } else hidePill()
            }
        }, f)

        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if ((st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0) showPill()
    }

    private fun su(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o.trim()
    } catch (e: Exception) { "" }

    private fun bg(block: () -> Unit) = Thread(block).start()

    private fun reapply() {
        val m = prefs.getInt("mode", -1)
        if (m >= 0) bg { su("echo $m > $node") }
    }

    private fun chip(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        setPadding((14 * dp).toInt(), (6 * dp).toInt(), (14 * dp).toInt(), (6 * dp).toInt())
        background = GradientDrawable().apply { setColor(0xFF2A2A2E.toInt()); cornerRadius = 100 * dp }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = (6 * dp).toInt() }
        visibility = View.GONE
    }

    private fun showPill() {
        if (pill != null) return
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = 100 * dp }
        }
        label = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "⚡ …" }
        fastBtn = chip("Fast"); slowBtn = chip("Slow")
        fastBtn.setOnClickListener { set(0) }
        slowBtn.setOnClickListener { set(1) }
        p.addView(label); p.addView(fastBtn); p.addView(slowBtn)
        p.setOnClickListener { toggle() }

        lp = WindowManager.LayoutParams(
            (120 * dp).toInt(), (36 * dp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (10 * dp).toInt() }
        wm.addView(p, lp); pill = p
        refresh()
    }

    private fun hidePill() {
        pill?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pill = null; expanded = false
    }

    private fun refresh() = bg {
        val v = su("cat $node")
        ui.post { if (pill != null) {
            label.text = if (v == "0") "⚡ Fast" else if (v == "1") "🐢 Slow" else "⚡ ?"
            fastBtn.alpha = if (v == "0") 1f else 0.5f
            slowBtn.alpha = if (v == "1") 1f else 0.5f
        } }
    }

    private fun set(m: Int) {
        prefs.edit().putInt("mode", m).apply()
        bg { su("echo $m > $node"); refresh() }
        ui.removeCallbacks(collapse); ui.postDelayed(collapse, 1200)
    }

    private fun toggle() {
        expanded = !expanded
        val vis = if (expanded) View.VISIBLE else View.GONE
        fastBtn.visibility = vis; slowBtn.visibility = vis
        if (expanded) { refresh(); ui.postDelayed(collapse, 5000) } else ui.removeCallbacks(collapse)
        val w0 = lp.width; val h0 = lp.height
        val w1 = ((if (expanded) 280 else 120) * dp).toInt()
        val h1 = ((if (expanded) 52 else 36) * dp).toInt()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 350; interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                val t = it.animatedValue as Float
                lp.width = (w0 + (w1 - w0) * t).toInt(); lp.height = (h0 + (h1 - h0) * t).toInt()
                pill?.let { v -> try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }
            }
        }.start()
    }

    override fun onDestroy() { hidePill(); super.onDestroy() }
}
