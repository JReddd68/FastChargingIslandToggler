package com.example.afc

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

class BatteryView(c: Context) : View(c) {
    private val d = resources.displayMetrics.density
    private var level = 0.0
    private var color = 0xFF30D158.toInt()
    private var phase = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 700; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    fun set(level: Double, color: Int, fast: Boolean) {
        this.level = level; this.color = color
        val t = if (fast) 700L else 1900L
        if (anim.duration != t) anim.duration = t
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val nub = 4 * d
        val body = RectF(1.5f * d, 1.5f * d, w - nub - d, h - 1.5f * d)
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0xCCFFFFFF.toInt()
        cv.drawRoundRect(body, 8 * d, 8 * d, p)
        p.style = Paint.Style.FILL
        cv.drawRoundRect(RectF(w - nub, h * 0.33f, w, h * 0.67f), 2 * d, 2 * d, p)

        val inner = RectF(body.left + 3 * d, body.top + 3 * d, body.right - 3 * d, body.bottom - 3 * d)
        val fw = inner.width() * (level / 100.0).toFloat().coerceIn(0f, 1f)
        cv.save()
        cv.clipPath(Path().apply { addRoundRect(inner, 5 * d, 5 * d, Path.Direction.CW) })
        p.reset(); p.isAntiAlias = true; p.color = color
        cv.drawRect(inner.left, inner.top, inner.left + fw, inner.bottom, p)
        val band = inner.width() * 0.45f
        val x = inner.left - band + (fw + band) * phase
        p.shader = LinearGradient(x, 0f, x + band, 0f,
            intArrayOf(0x00FFFFFF, 0x99FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        cv.drawRect(inner.left, inner.top, inner.left + fw, inner.bottom, p)
        p.shader = null
        cv.restore()

        val cx = body.centerX(); val cy = body.centerY(); val s = h * 0.32f
        val bolt = Path().apply {
            moveTo(cx + s * 0.15f, cy - s); lineTo(cx - s * 0.55f, cy + s * 0.15f)
            lineTo(cx - s * 0.05f, cy + s * 0.15f); lineTo(cx - s * 0.2f, cy + s)
            lineTo(cx + s * 0.55f, cy - s * 0.2f); lineTo(cx + s * 0.05f, cy - s * 0.2f); close()
        }
        p.reset(); p.isAntiAlias = true; p.color = 0xFFFFFFFF.toInt()
        cv.drawPath(bolt, p)
    }
}
