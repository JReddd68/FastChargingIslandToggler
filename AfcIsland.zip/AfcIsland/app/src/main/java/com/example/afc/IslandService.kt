package com.example.afc

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp

class IslandService : Service() {
    companion object {
        const val ACTION_SHOW = "show"
        const val ACTION_RELOAD = "reload"
        const val NODE = "/sys/class/sec/switch/afc_disable"
        val GREEN = 0xFF30D158.toInt()
        val BLUE = 0xFF0A84FF.toInt()
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var bm: BatteryManager
    private lateinit var notif: Notification
    private val prefs by lazy { getSharedPreferences("afc", MODE_PRIVATE) }
    private val dp get() = resources.displayMetrics.density

    private var plugged = false
    private var lastSched = -1      // -1 = not applied yet, -2 = schedule off handled
    private var curMode = -1        // 0 fast, 1 slow
    private var fullUah = 0L
    private var lastT = 0L
    private var lastSample = 0L
    private var sCap = 0
    private var sFull = 0.0
    private var charging = false
    private var est = 0.0
    private var shownPct = 0.0
    private var targetMa = 0.0
    private var shownMa = 0.0
    private var deadline = 0L

    private var holder: FrameLayout? = null
    private lateinit var card: SwipeCard
    private lateinit var battery: BatteryView
    private lateinit var pctText: TextView
    private lateinit var statusText: TextView
    private lateinit var fastBtn: TextView
    private lateinit var slowBtn: TextView

    override fun onBind(i: Intent?): IBinder? = null

    private val hideRun = Runnable { hideIsland(true) }

    private val tick = object : Runnable {
        override fun run() {
            if (!plugged) return
            checkSchedule()
            ui.postDelayed(this, 30000)
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (holder == null) return
            step()
            pctText.text = String.format(Locale.US, "%.2f%%", shownPct)
            battery.set(shownPct, if (curMode == 1) BLUE else GREEN, curMode != 1)
            updateStatus()
            ui.postDelayed(this, 50)
        }
    }

    private val powerRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_POWER_CONNECTED) {
                plugged = true
                ui.postDelayed({
                    if (plugged) {
                        lastSched = -1
                        ui.removeCallbacks(tick); ui.post(tick)
                        showIsland()
                    }
                }, 2500)
            } else {
                plugged = false
                ui.removeCallbacks(tick)
                hideIsland(false)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("afc", "AFC Island", NotificationManager.IMPORTANCE_MIN))
        notif = Notification.Builder(this, "afc")
            .setContentTitle("AFC Island running")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging).build()

        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        plugged = (st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        registerReceiver(powerRx, IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        })
        if (plugged) ui.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(1, notif)
        when (i?.action) {
            ACTION_SHOW -> showIsland()
            ACTION_RELOAD -> if (plugged) { lastSched = -1; ui.removeCallbacks(tick); ui.post(tick) }
        }
        return START_STICKY
    }

    // ---------- root + helpers ----------
    private fun su(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o.trim()
    } catch (e: Exception) { "" }

    private fun bg(b: () -> Unit) { Thread(b).start() }

    private fun rounded(color: Int, r: Float): Drawable =
        GradientDrawable().apply { setColor(color); cornerRadius = r * dp }

    // ---------- charging mode + schedule ----------
    private fun inSlowWindow(): Boolean {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val s = prefs.getInt("slow_start", 21 * 60)
        val e = prefs.getInt("slow_end", 5 * 60)
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    // most recent moment the schedule switched (start or end time)
    private fun lastBoundaryMs(): Long {
        val now = System.currentTimeMillis()
        var best = 0L
        for (m in intArrayOf(prefs.getInt("slow_start", 21 * 60), prefs.getInt("slow_end", 5 * 60))) {
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis > now) c.add(Calendar.DAY_OF_YEAR, -1)
            best = maxOf(best, c.timeInMillis)
        }
        return best
    }

    // your last manual tap wins until the next schedule boundary passes
    private fun desired(): Int {
        val man = prefs.getInt("manual", -1)
        if (!prefs.getBoolean("sched_on", true)) return man
        if (man >= 0 && prefs.getLong("manual_ts", 0L) > lastBoundaryMs()) return man
        return if (inSlowWindow()) 1 else 0
    }

    private fun checkSchedule() {
        val d = desired()
        if (d >= 0 && d != lastSched) { lastSched = d; writeMode(d) }
    }

    private fun writeMode(m: Int) = bg {
        su("echo $m > $NODE")
        val v = su("cat $NODE").toIntOrNull() ?: m
        ui.post { curMode = v; updateModeUi() }
    }

    private fun setManual(m: Int) {
        prefs.edit().putInt("manual", m).putLong("manual_ts", System.currentTimeMillis()).apply()
        lastSched = m
        writeMode(m)
    }

    // ---------- predicted percentage + animated current ----------
    private fun effFull(cap: Double, c: Long): Double =
        if (fullUah > 0) fullUah.toDouble() else if (cap > 0 && c > 0) c * 100.0 / cap else 0.0

    // Percent: the system integer is the floor. The decimals are predicted from the measured current
    // (mA / capacity), climbing xx.00 -> xx.99, then reset to the next xx.00 when the gauge flips.
    // mA: the shown value glides toward each new reading (about 4 s to settle).
    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val first = lastT == 0L
        val dt = if (first) 0.0 else (now - lastT) / 1000.0
        lastT = now
        if (first || now - lastSample >= 250) {
            lastSample = now
            sCap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val c = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            sFull = effFull(sCap.toDouble(), c)
            targetMa = abs(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)) / 1000.0
            charging = bm.isCharging
            if (first) {
                val raw = if (sFull > 0 && c > 0) c * 100.0 / sFull else sCap.toDouble()
                est = raw.coerceIn(sCap.toDouble(), sCap + 0.99)
                shownPct = est; shownMa = targetMa
            }
        }
        shownMa += (targetMa - shownMa) * (1 - exp(-dt / 0.9))
        if (sFull > 0 && charging) est += shownMa * 1000.0 * dt / 3600.0 / sFull * 100.0
        est = est.coerceIn(sCap.toDouble(), sCap + 0.99)
        shownPct += (est - shownPct) * (1 - exp(-dt / 0.12))
    }

    // ---------- island UI ----------
    private fun seg(t: String) = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; textSize = 13f; setTextColor(Color.WHITE)
        setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
    }

    private fun updateStatus() {
        if (holder == null) return
        val l = if (curMode == 0) "RAPID CHARGING" else if (curMode == 1) "SLOW CHARGING" else "CHARGING"
        statusText.text = if (shownMa >= 1) "$l · ${shownMa.toInt()} mA" else l
    }

    private fun updateModeUi() {
        if (holder == null) return
        val fast = curMode == 0; val slow = curMode == 1
        updateStatus()
        statusText.setTextColor(if (slow) BLUE else GREEN)
        fastBtn.background = if (fast) rounded(0x6630D158, 12f) else null
        slowBtn.background = if (slow) rounded(0x660A84FF, 12f) else null
        fastBtn.alpha = if (fast) 1f else 0.6f
        slowBtn.alpha = if (slow) 1f else 0.6f
    }

    private fun showIsland() {
        ui.removeCallbacks(hideRun)
        if (holder == null) build()
        deadline = SystemClock.elapsedRealtime() + 10000
        ui.postDelayed(hideRun, 10000)
    }

    // finger down = stay open; on release keep it at least 3 s more
    private fun holdIsland(held: Boolean) {
        if (holder == null) return
        ui.removeCallbacks(hideRun)
        if (!held) {
            val rem = maxOf(deadline - SystemClock.elapsedRealtime(), 3000L)
            deadline = SystemClock.elapsedRealtime() + rem
            ui.postDelayed(hideRun, rem)
        }
    }

    private fun build() {
        val d = dp
        battery = BatteryView(this)
        pctText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 26f; text = "--"
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            fontFeatureSettings = "tnum"
        }
        statusText = TextView(this).apply { textSize = 12f; letterSpacing = 0.08f }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(pctText); addView(statusText)
        }
        val row1 = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(battery, LinearLayout.LayoutParams((56 * d).toInt(), (28 * d).toInt()))
            addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = (12 * d).toInt() })
        }
        fastBtn = seg("⚡ Fast"); slowBtn = seg("🌙 Slow")
        fastBtn.setOnClickListener { setManual(0) }
        slowBtn.setOnClickListener { setManual(1) }
        val segRow = LinearLayout(this).apply {
            background = rounded(0x22FFFFFF, 15f)
            val pd = (3 * d).toInt(); setPadding(pd, pd, pd, pd)
            addView(fastBtn, LinearLayout.LayoutParams(0, -2, 1f))
            addView(slowBtn, LinearLayout.LayoutParams(0, -2, 1f))
        }
        card = SwipeCard(this, { hideIsland(true) }, { held -> holdIsland(held) }).apply {
            orientation = LinearLayout.VERTICAL
            val pd = (16 * d).toInt(); setPadding(pd, (14 * d).toInt(), pd, (14 * d).toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF17171B.toInt(), 0xFF000000.toInt())).apply {
                cornerRadius = 32 * d; setStroke(maxOf(1, d.toInt()), 0x33FFFFFF)
            }
            addView(row1)
            addView(segRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * d).toInt() })
        }
        val h = FrameLayout(this).apply {
            val pd = (14 * d).toInt(); setPadding(pd, pd, pd, pd)
            addView(card, FrameLayout.LayoutParams(-1, -2))
        }
        val width = minOf((340 * d).toInt(), resources.displayMetrics.widthPixels)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }
        wm.addView(h, lp)
        holder = h

        card.alpha = 0f; card.scaleX = 0.5f; card.scaleY = 0.5f; card.translationY = -40 * d
        card.post {
            card.pivotX = card.width / 2f; card.pivotY = 0f
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(450).setInterpolator(OvershootInterpolator(1.2f)).start()
        }

        updateModeUi()
        bg {
            val v = su("cat $NODE").toIntOrNull() ?: -1
            if (fullUah == 0L) fullUah = su("cat /sys/class/power_supply/battery/charge_full").toLongOrNull() ?: 0L
            ui.post { curMode = v; updateModeUi() }
        }
        lastT = 0L
        ui.post(poll)
    }

    private fun hideIsland(animate: Boolean) {
        ui.removeCallbacks(hideRun); ui.removeCallbacks(poll)
        val h = holder ?: return
        holder = null
        val remove = { try { wm.removeView(h) } catch (_: Exception) {} }
        if (animate) {
            card.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).translationY(-24 * dp)
                .setDuration(250).withEndAction { remove() }.start()
        } else remove()
    }

    override fun onDestroy() {
        try { unregisterReceiver(powerRx) } catch (_: Exception) {}
        ui.removeCallbacksAndMessages(null)
        hideIsland(false)
        super.onDestroy()
    }
}
